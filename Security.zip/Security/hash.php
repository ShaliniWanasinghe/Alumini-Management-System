<?php
echo password_hash("#123ABC", PASSWORD_DEFAULT);
?>

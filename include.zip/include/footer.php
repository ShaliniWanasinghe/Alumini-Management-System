<footer class="footer">
    <p>&copy; <?php echo date("Y"); ?> AlumSphere | Open Source under MIT License</p>
</footer>

<?php
include 'db_connect.php';

$popupMessage = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["csv_file"])) {
    $file = $_FILES["csv_file"]["tmp_name"];

    if (($handle = fopen($file, "r")) !== FALSE) {
        $incomplete = false;

        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            if (count($data) < 10 || in_array("", $data)) {
                $incomplete = true;
                continue;
            }

            // Sanitize input
            list($name, $personal_email, $student_email, $birthdate, $reg_no, $faculty, $batch, $designation, $address, $contact_number) = array_map('trim', $data);

            // Check for duplicates
            $stmt_check = $conn->prepare("SELECT student_email FROM alumni WHERE student_email = ?");
            $stmt_check->bind_param("s", $student_email);
            $stmt_check->execute();
            $result = $stmt_check->get_result();

            if ($result->num_rows == 0) {
                $stmt_insert = $conn->prepare("INSERT INTO alumni (name, personal_email, student_email, birthdate, reg_no, faculty, batch, designation, address, contact_number) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt_insert->bind_param("ssssssssss", $name, $personal_email, $student_email, $birthdate, $reg_no, $faculty, $batch, $designation, $address, $contact_number);
                $stmt_insert->execute();
            }
        }
        fclose($handle);

        if ($incomplete) {
            $popupMessage = "Some rows in your CSV file had missing fields and were skipped.";
        } else {
            header("Location: view_my_details.php");
            exit;
        }
    } else {
        $popupMessage = "Failed to open the CSV file.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Upload Alumni CSV - AlumSphere</title>
    <link rel="stylesheet" href="style7.css">
</head>
<body>
    <div class="container">
        <h1>AlumSphere</h1>
        <h2>Upload Alumni Details</h2>

        <div class="csv-fields">
    <div class="csv-header">
        <img src="https://cdn-icons-png.flaticon.com/512/2991/2991108.png" alt="CSV icon" class="csv-icon">
        <div>
            <h4>CSV Fields Required (in order)</h4>
            <p class="csv-subtext">Your CSV file should include the following fields in exactly this order:</p>
        </div>
    </div>

    <ul class="csv-list">
        <li>Name</li>
        <li>Personal Email</li>
        <li>Student Email</li>
        <li>Birthdate <small>(YYYY-MM-DD)</small></li>
        <li>Registration Number</li>
        <li>Faculty</li>
        <li>Batch</li>
        <li>Designation</li>
        <li>Address</li>
        <li>Contact Number</li>
    </ul>

    <div class="csv-warning">
        ⚠️ Ensure your CSV follows this structure. Duplicate student emails will be skipped.
    </div>
</div>


        <form action="" method="post" enctype="multipart/form-data">
            <input type="file" name="csv_file" accept=".csv" required>
            <button type="submit">Upload CSV</button>
        </form>
        <p><a href="dashboard.php">Back to Dashboard</a></p>
    </div>

    <?php if (!empty($popupMessage)): ?>
        <script>
            alert("<?php echo addslashes($popupMessage); ?>");
        </script>
    <?php endif; ?>
</body>
</html>